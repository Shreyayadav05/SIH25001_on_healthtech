def send_whatsapp(msg):
    print("📲 WhatsApp Alert Sent:", msg)

def send_sms(msg):
    print("📡 SMS Sent:", msg)
send_whatsapp("HIGH RISK OUTBREAK DETECTED")
send_sms("Emergency: Waterborne disease risk high")
